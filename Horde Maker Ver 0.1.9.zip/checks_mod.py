"""
SDEV 140-53P
T. Newell

Final Project

***Class Checks***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""
"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""

import random as ran
from tkinter import messagebox


class Checks:#creates static methods used throughout the program
    """Not Initialized because it is just object storage of related functions"""
    @staticmethod
    def is_int(x): 
    #Verifies if entry is interger entered how requested
        try:
            if int(x) and int(x) > 0:
                return True
            else:
                return False
        except ValueError:
            messagebox.showerror(title = 'Entry Error', message = """Your entry was not entered correctly.
Please try again.""")
            
    @staticmethod        
    def rangen(max,stop, min =1):
    # generates random numbers
        _numbers = []
        for i in range(int(stop)):
            #generates a random HP for monsters in horde
            number = ran.randint(int(min),int(max)) 
            _numbers.append(number)
        return _numbers
