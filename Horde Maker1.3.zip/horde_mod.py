"""
Michael Gentile
4/24/23
SDEV 140-53P
T. Newell

Final Project

***Horde Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""

"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""

import random as ran

def is_int(x): 
    #Verifies if entry is interger entered how requested
    try: 
        if int(x) and int(x) > 0:
            return True
        else:
            print ("That was not entered correctly.  Please try again.")
            return False
    except ValueError:
        print("That was not entered correctly.  Please try again.")
        return False

def rangen(max,stop, min =1):
    # generates random numbers
    numbers = []
    for i in range(int(stop)):
        #generates a random HP for monsters in horde
        number = ran.randint(int(min),int(max)) 
        numbers.append(number)
    return numbers
    
def horde():
    #This is horde main receives input and provides output for horde module.
    seq = 0 #Counter 
    monhp = [] #Storage for random numbers generated
    hordehp = input("Enter the max HP for the your monster class:\n")
    while is_int(hordehp) == False:
        #If input was wrong user can fix it
        hordehp = input("Enter the max HP for the your monster class:\n")
        
    nummon = input("Enter the number of monsters in your Horde:\n")
    while is_int(hordehp) == False:
        #If input was wrong user can fix it
        hordehp = input("Enter the number of monsters in your Horde:\n")
    print("\n")
    monhp = rangen(hordehp,nummon)#Receives Random numbers from generator 
    # for i in range(len(monhp)):
    #     #Prepares and prints output of Monsters HP
    #     seq = seq + 1
        # print ("Monster {} is {} HP".format(seq,monhp[i]))
    return monhp
        

# if __name__ == horde():
#     horde()