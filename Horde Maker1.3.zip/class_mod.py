"""
SDEV 140-53P
T. Newell

Final Project

***Class Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""
"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""


import random as ran

#This section creates dictionary for the character class labels
class_def = {}
class_def['1'] = 'Artificer'
class_def['2'] = 'Barbarian'
class_def['3'] = 'Bard (Dexterity Preferred)'
class_def['4'] = 'Bard (Wisdom Preferred)'
class_def['5'] = 'Cleric'
class_def['6'] = 'Druid (Charisma Preferred)'
class_def['7'] = 'Druid (Constitution Preferred)'
class_def['8'] = 'Fighter (Dexterity Preferred)'
class_def['9'] = 'Fighter (Strength Preferred)'
class_def['10'] = 'Monk'
class_def['11'] = 'Paladin'
class_def['12'] = 'Ranger'
class_def['13'] = 'Rogue'
class_def['14'] = 'Sorcerer'
class_def['15'] = 'Warlock'
class_def['16'] = 'Wizard'

#This section creates dictionary for the character class files
class_file = {}
class_file['1'] = 'Artificer.txt'
class_file['2'] = 'Barbarian.txt'
class_file['3'] = 'bard_dex.txt'
class_file['4'] = 'Bard_wis.txt'
class_file['5'] = 'Cleric.txt'
class_file['6'] = 'Druid_cha.txt'
class_file['7'] = 'Druid_con.txt'
class_file['8'] = 'Fighter_dex.txt'
class_file['9'] = 'Fighter_str.txt'
class_file['10'] = 'Monk.txt'
class_file['11'] = 'Paladin.txt'
class_file['12'] = 'Ranger.txt'
class_file['13'] = 'Rogue.txt'
class_file['14'] = 'Sorcerer.txt'
class_file['15'] = 'Warlock.txt'
class_file['16'] = 'Wizard.txt'


def is_int(x): 
    #Verifies if entry is interger entered how requested
    try: 
        if int(x) and int(x) > 0:
            return True
        else:
            return False
    except ValueError:
        return False
    
def char_file(char_class_f):
    #This section opens the .txt file for character class selected
    file = open(class_file.get(char_class_f), "r")
    details = main_char_def(file)
    file.close()
    return details

def rangen(max,stop, min =1):
    # generates random numbers
    numbers = []
    for i in range(int(stop)):
        #generates a random HP for monsters in horde
        number = ran.randint(int(min),int(max)) 
        numbers.append(number)
    return numbers
  
def main_char_def(x):
    #Changes character .txt list to definitions and returns definitions
    charatt = {}
    for line in x:
        (key, value) = line.split()
        charatt[(key)] = value
    return charatt
            


def att_main():
    #Receives input and generates the desired output
    char_att = rangen(18,6,6)#Random number list
    
    char_att.sort(reverse = True)#Sorted list assignment
    # Next section creates menu and receives input
    menu = """1 - Artificer                           2 - Barbarian
3 - Bard (Dex preferred)                4 - Bard (Wis preferred)
5 - Cleric                              6 - Druid (Cha preferred)
7 - Druid (Con preferred)               8 - Fighter (Dex preferred)
9 - Fighter (Str preferred)             10 - Monk
11 - Paladin                            12 - Ranger
13 - Rogue                              14 - Sorcerer
15 - Warlock                            16 - Wizard"""
    print (menu)
    char_class = input ("\nSelect the number for your character's class:\n")
    while is_int(char_class) == False or int(char_class) > 16:
        #Verifies input for this jumptable
        print ("That was not entered correctly.  Please try again.")
        char_class = input ("\nSelect the number for your character's class:\n")
    char_def = char_file(char_class)
    #next section uses txt file to create new definition and results
    for key, value in char_def.items():
        if value == "max":
            char_def[key] = int(max(char_att))
        elif value == "max-1":
            char_def[key] = int(char_att[1])
        elif value == "min":
            char_def[key] = int(min(char_att))
        else:
            if len(char_att) > 5:
                x = ran.randint(-4,-2)
                char_def[key] = int(char_att.pop(x))
            elif len(char_att) > 4:
                x = ran.randint(-3,-2)
                char_def[key] = int(char_att.pop(x))
            else:
                char_def[key] = int(char_att.pop(-2))
    char_def['Free'] = '' #Adds the free Key to dict for easy iteration later
    return char_def, class_def[char_class]
            