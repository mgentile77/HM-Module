"""
SDEV 140-53P
T. Newell

Final Project

***Level Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""

"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""


def is_int(x): 
    #Verifies if entry is interger entered how requested
    try: 
        if int(x) and int(x) > 0:
            return True
        else:
            return False
    except ValueError:
        return False

#This section sets dictionionary for level points
levelbonus = {}
levelbonus[4] = 2
levelbonus[8] = 4
levelbonus[12] = 6
levelbonus[16] = 8
levelbonus[19] = 10

def abil_bonus():
    #Main bonus calculator
    #This section sets the local variables and colledcts input
    ability = {}
    level = input ("Please enter your character's level:\n")
    while is_int(level) == False or int(level) > 20:
        #This section verifies input
        print ("That was not entered correctly.  Please try again.")
        level = input ("\nPlease enter your character's level (DnD 5e levels cannot exceed 20):\n")
    #This section sets the level bonus and prepares a dictionary
    if int(level) >18:
        ability['Free'] = levelbonus.get(19)
    elif int(level) > 15:
        ability['Free'] = levelbonus.get(16)
    elif int(level) > 11:
        ability['Free'] = levelbonus.get(12)
    elif int(level) > 7:
        ability['Free'] = levelbonus.get(8)
    elif int(level) > 3:
        ability['Free'] = levelbonus.get(4)
    else:
        ability['Free'] = 0
    return ability #Returns results
    # print (ability)

# if __name__ == abil_bonus():
#     abil_bonus()