"""
SDEV 140-53P
T. Newell

Final Project

***Class Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""
"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""


import random as ran

class_def = {}
class_def['1'] = 'Artificer'
class_def['2'] = 'Barbarian'
class_def['3'] = 'Bard (Dexterity Preferred)'
class_def['4'] = 'Bard (Wisdom Preferred)'
class_def['5'] = 'Cleric'
class_def['6'] = 'Druid (Charisma Preferred)'
class_def['7'] = 'Druid (Constitution Preferred)'
class_def['8'] = 'Fighter (Dexterity Preferred)'
class_def['9'] = 'Fighter (Strength Preferred)'
class_def['10'] = 'Monk'
class_def['11'] = 'Paladin'
class_def['12'] = 'Ranger'
class_def['13'] = 'Rogue'
class_def['14'] = 'Sorcerer'
class_def['15'] = 'Warlock'
class_def['16'] = 'Wizard'

def is_int(x): 
    #Verifies if entry is interger entered how requested
    try: 
        if int(x) and int(x) > 0:
            return True
        else:
            return False
    except ValueError:
        return False

def rangen(max,stop, min =1):
    # generates random numbers
    numbers = []
    for i in range(int(stop)):
        #generates a random HP for monsters in horde
        number = ran.randint(int(min),int(max)) 
        numbers.append(number)
    return numbers
  
def main_char_def(x):
    #Changes character .txt list to definitions and returns definitions
    charatt = {}
    for line in x:
        (key, value) = line.split()
        charatt[(key)] = value
    return charatt
            
#This section opens the .txt file for character class selected
def artificer():
    char_file = open("Artificer.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details
    
def barbarian():
    char_file = open("Barbarian.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details


def bard_dex():
    char_file = open("Bard_dex.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def bard_wis():
    char_file = open("Bard_wis.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def cleric():
    char_file = open("Cleric.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def druid_cha():
    char_file = open("Druid_cha.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def druid_con():
    char_file = open("Druid_con.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def fighter_dex():
    char_file = open("Fighter_dex.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def fighter_str():
    char_file = open("Fighter_str.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def monk():
    char_file = open("Monk.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def paladin():
    char_file = open("Paladin.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def ranger():
    char_file = open("Ranger.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def rogue():
    char_file = open("Rogue.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def sorcerer():
    char_file = open("Sorcerer.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def warlock():
    char_file = open("Warlock.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def wizard():
    char_file = open("Wizard.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

#This section creates jump table for the character classes
jumpTable1 = {}
jumpTable1['1'] = artificer
jumpTable1['2'] = barbarian
jumpTable1['3'] = bard_dex
jumpTable1['4'] = bard_wis
jumpTable1['5'] = cleric
jumpTable1['6'] = druid_cha
jumpTable1['7'] = druid_con
jumpTable1['8'] = fighter_dex
jumpTable1['9'] = fighter_str
jumpTable1['10'] = monk
jumpTable1['11'] = paladin
jumpTable1['12'] = ranger
jumpTable1['13'] = rogue
jumpTable1['14'] = sorcerer
jumpTable1['15'] = warlock
jumpTable1['16'] = wizard

def att_main(char_class):
    #Receives input and generates the desired output
    char_att = rangen(18,6,6)#Random number list
    
    char_att.sort(reverse = True)#Sorted list assignment
    #Next section creates menu and receives input
#     menu = """1 - Artificer                           2 - Barbarian
# 3 - Bard (Dex preferred)                4 - Bard (Wis preferred)
# 5 - Cleric                              6 - Druid (Cha preferred)
# 7 - Druid (Con preferred)               8 - Fighter (Dex preferred)
# 9 - Fighter (Str preferred)             10 - Monk
# 11 - Paladin                            12 - Ranger
# 13 - Rogue                              14 - Sorcerer
# 15 - Warlock                            16 - Wizard"""
#     print (menu)
    # char_class = input ("\nSelect the number for your character's class:\n")
    # while is_int(char_class) == False or int(char_class) > 16:
    #     #Verifies input for this jumptable
    #     print ("That was not entered correctly.  Please try again.")
    #     char_class = input ("\nSelect the number for your character's class:\n")
    char_def = jumpTable1[char_class]()
    #checks for accuracy, will be removed before deployment
    # print (char_def)
    # print (char_att)
    #next section uses txt file to create new definition and results
    for key, value in char_def.items():
        if value == "max":
            char_def[key] = int(max(char_att))
        elif value == "max-1":
            char_def[key] = int(char_att[1])
        elif value == "min":
            char_def[key] = int(min(char_att))
        else:
            if len(char_att) > 5:
                x = ran.randint(-4,-2)
                char_def[key] = int(char_att.pop(x))
            elif len(char_att) > 4:
                x = ran.randint(-3,-2)
                char_def[key] = int(char_att.pop(x))
            else:
                char_def[key] = int(char_att.pop(-2))
    char_def['Free'] = ''
    return char_def
    #Finally we print results for the character class
#     print ("\nYour {} has these stats:".format(class_def[char_class]))
#     for k in char_def:
#         print ("%-18s%-5s" %(k, char_def[k]))

# if __name__ == att_main():
#     att_main()
            