

import random as ran
from tkinter import messagebox


class Checks:

    @staticmethod
    def is_int(x): 
    #Verifies if entry is interger entered how requested
        try:
            if int(x) and int(x) > 0:
                return True
            else:
                return False
        except ValueError:
            messagebox.showerror(title = 'Entry Error', message = """Your entry was not entered correctly.
Please try again.""")
            
    @staticmethod        
    def rangen(max,stop, min =1):
    # generates random numbers
        _numbers = []
        for i in range(int(stop)):
            #generates a random HP for monsters in horde
            number = ran.randint(int(min),int(max)) 
            _numbers.append(number)
        return _numbers
