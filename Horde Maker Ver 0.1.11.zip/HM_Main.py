"""
SDEV 140-53P
T. Newell

Final Project

***Class GUI Main***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""

#Imports needed Modules
import tkinter as tk
from tkinter import *
from tkinter.constants import *
from tkinter import ttk
from tkinter import messagebox
from class_mod import Class_main
from race_mod import Race_main
from level_mod import Level_Bonus
from checks_mod import *
import os

#Creates Class Dictionary for use
class_def = {}
class_def['1'] = 'Artificer'
class_def['2'] = 'Barbarian'
class_def['3'] = 'Bard (Dexterity Preferred)'
class_def['4'] = 'Bard (Wisdom Preferred)'
class_def['5'] = 'Cleric'
class_def['6'] = 'Druid (Charisma Preferred)'
class_def['7'] = 'Druid (Constitution Preferred)'
class_def['8'] = 'Fighter (Dexterity Preferred)'
class_def['9'] = 'Fighter (Strength Preferred)'
class_def['10'] = 'Monk'
class_def['11'] = 'Paladin'
class_def['12'] = 'Ranger'
class_def['13'] = 'Rogue'
class_def['14'] = 'Sorcerer'
class_def['15'] = 'Warlock'
class_def['16'] = 'Wizard'

#Creates Race Dictionary for Use
race_def = {}
race_def['1'] = 'Dragonborn'
race_def['2'] = 'Dwarf'
race_def['3'] = 'Elf'
race_def['4'] = 'Genasi'
race_def['5'] = 'Half-Elf'
race_def['6'] = 'Half-Orc'
race_def['7'] = 'Halfling'
race_def['8'] = 'Human'
race_def['9'] = 'Tiefling'

class Horde_Maker(tk.Tk):
    #Main Window class all other windows come from here
    def __init__(self):#Initializes the main window and starts program
        super().__init__()
        #This sections creates window size and location on pop up 
        width = 380
        height = 205
        screen_wid = self.winfo_screenwidth()
        screen_hei = self.winfo_screenheight()
        x = (screen_wid/2) - (width/2)
        y = (screen_hei/2) - (height/2)
        self.title("Horde Maker")
        self.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.configure(bg = '#e1d8b9')
        self.protocol("WM_DELETE_WINDOW", self.disable_Xclose)
        self.back_image = tk.PhotoImage(file = os.path.abspath(os.path.join(os.getcwd(), 'Images', 'main_back2.gif')))
        self.style = ttk.Style()
        self.style.configure('nbutton.TButton', background = '#e1d8b9', width = 18, height = 34)
        self.style2 = ttk.Style()
        self.style2.configure('n2button.TButton', background = '#e1d8b9')
        #Begins layout of window widgets
        self.set_up()
        
    def set_up(self):
        #sets up window widgets for this class    
        self.frame_start = tk.Frame(bg = '#e1d8b9')#Frame for start welcome and instructions
        self.frame_start.pack(padx = (0,10))
        self.image_start = tk.Label(self.frame_start, bg = '#e1d8b9', image = self.back_image)
        self.image_start.grid(row = 0, column = 0, rowspan = 5, sticky = 'nsew')
        tk.Label(self.frame_start, text = "Welcome To The",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '12', 'bold')).grid(row = 0, column = 1, columnspan = 2)
        tk.Label(self.frame_start, text = "HORDE MAKER",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '24', 'bold')).grid(row = 1, column = 1, columnspan = 2)
        tk.Label(self.frame_start, text = "Choose Your Path",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '12', 'bold')).grid(row = 2, column = 1, columnspan = 2)
        
        self.but_horde = ttk.Button(self.frame_start, style = 'nbutton.TButton', text = "Horde Maker", command = self.hordebutton)
        self.but_horde.grid(row = 3, column = 1, sticky = 'nsew')
        
        self.but_char = ttk.Button(self.frame_start, style = 'nbutton.TButton',text = "Character Builder", command = self.characterbutton)
        self.but_char.grid(row = 3, column = 2, sticky = 'nsew')
        ttk.Button(self.frame_start, text = 'Exit', style = 'n2button.TButton',command = lambda : exit()).grid(row = 4, column = 1, columnspan = 2)

    #Begins Class methods used in functions of of buttons
    def hordebutton(self):#opens Horde window
        new_win1 = Horde(self)
        new_win1.grab_set()
        
    def characterbutton(self):#opens Character Window
        new_win2 = Character(self)
        new_win2.grab_set()

    #Creates parent class instructions for other windows    
    def clear_frame(frame):#Destroys child window on exit 
        for widgets in frame.winfo_children():
            widgets.destroy() 

    def disable_Xclose(self):#prevents closing the window by using corner X
        pass

class Character(tk.Toplevel):
    #Begins the character window
    global total_abil #sets variable to be used throughout class
    total_abil = {} #creates dictionary list for later use

    def __init__(self, parent):
        #Sets window parameters as in main but for this window
        super().__init__(parent)
        self.width = 400
        self.height = 265
        self.screen_wid = self.winfo_screenwidth()
        self.screen_hei = self.winfo_screenheight()
        self.x = (self.screen_wid/2) - (self.width/2)
        self.y = (self.screen_hei/2) - (self.height/2)
        self.geometry("%dx%d+%d+%d" % (self.width, self.height, self.x, self.y))
        self.configure(bg = '#e1d8b9')
        self.style = ttk.Style()
        self.style.configure('nbutton.TButton', background = '#e1d8b9', width = 18, height = 34)
        self.title("Character Creator")
        self.back_image = tk.PhotoImage(file = os.path.abspath(os.path.join(os.getcwd(), 'Images', 'char_back5.gif')))
        self.win2_set()#Begins the layout of widgets

    def win2_set(self):
        #contains widget layout for this window   
        self.options1 = tk.StringVar()#Sets container for options menu and sets default
        self.options2 = tk.StringVar()#Sets container for options menu and sets default
        
        self.frame_head3 = tk.Frame(self, bg = '#e1d8b9')#Frame for image
        self.frame_head3.grid(row = 0, column = 0, padx = (10,0))
        self.char_back = tk.Label(self.frame_head3, image = self.back_image, bg = '#e1d8b9')
        self.char_back.grid(row = 0, column = 2, rowspan = 8, sticky = 'nsew')
        
        #Begins options menus and entry menu
        tk.Label(self.frame_head3, text = "Time to get a character!",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '18', 'bold')).grid(row = 0, column = 0, columnspan = 2)
        tk.Label(self.frame_head3, text = "Choose your Class",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '12')).grid(row = 1, column = 0, columnspan = 2)
        self.menu1 = ttk.OptionMenu(self.frame_head3, self.options1, class_def['1'], *class_def.values())
        self.menu1.grid(row = 2, column = 0, columnspan = 2)
        tk.Label(self.frame_head3, text = "Choose your Race",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '12')).grid(row = 3, column = 0, columnspan = 2)
        self.menu2 = ttk.OptionMenu(self.frame_head3, self.options2,race_def['1'], *race_def.values())
        self.menu2.grid(row = 4, column = 0, columnspan = 2)
        tk.Label(self.frame_head3, text = "Enter your player Level",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '12')).grid(row = 5, column = 0, columnspan = 2)
        
        self.entry3 = tk.StringVar(self.frame_head3, 3)#creates container for entry 
        self.char_lev = ttk.Entry(self.frame_head3, width = 2, textvariable = self.entry3)
        self.char_lev.grid(row = 6, column = 0, columnspan = 2)
        
        def limit3(*args):#Limits number of digits permitted in field
            value = self.entry3.get()
            if len(value) > 2:
                self.entry3.set(value[:2])
        
        self.entry3.trace('w', limit3)#monitors field as input is enteres 
        
        self.results2 = tk.Frame(self, bg = '#e1d8b9')#setting up results panel
        self.results2.grid(row = 1, column = 0)
        
        ttk.Button(self.frame_head3, style = 'nbutton.TButton', text = "Submit", command = self.submit2).grid(row = 7, column = 0, sticky = 'e')
        ttk.Button(self.frame_head3, style = 'nbutton.TButton', text = "Exit", command = self.destroy).grid(row = 7, column = 1, sticky = 'w')
        
    def get_class(self):#creates method for returning value
        for k, v in class_def.items():
            if self.options1.get() == v:
                return k
    
    def get_race(self):#creates method for returning value
        for k,v,in race_def.items():
            if self.options2.get() == v:
                return k
        
    def submit2(self):#Main character function that collects and performs work on data then returns results
        
        self.count = 4 #Counter variable
        Horde_Maker.clear_frame(self.results2)#Clears results frame
        self.geometry("%dx%d+%d+%d" % (self.width, self.height, self.x, self.y))
        new_height = 525
        new_y = (self.screen_hei/2) - (new_height/2)
        #begins to fetch data from other mods and produce results
        self.myclass = self.get_class()
        self.myrace = self.get_race()
        self.mylevel = self.entry3.get()
        self.new_char = Class_main().class_main(self.myclass)
        self.new_race = Race_main().race_main(self.myrace)
        self.new_level = Level_Bonus().level_bonus(self.mylevel)
        total_abil = self.total(self.new_char, self.new_race, self.new_level)
        
        #begins output of results
        your_char = "This is your Level {} {} {}.".format(self.mylevel, race_def[self.myrace], class_def[self.myclass])
        tk.Label(self.results2, text = your_char,
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '14'), wraplength = 325, justify = CENTER).grid(row = 1, column = 0, columnspan = 4)
        tk.Label(self.results2, bg = '#e1d8b9',
                 text = 'Ability', font = ('Baskerville Old Face', 12, 'bold underline'), justify = 'left').grid(sticky = 'w', row = 3, column = 0)
        tk.Label(self.results2, bg = '#e1d8b9',
                 text = 'Base', font = ('Baskerville Old Face', 12, 'bold underline'), justify = 'left').grid(row = 3, column = 1)
        tk.Label(self.results2, bg = '#e1d8b9',
                 text = 'Race Bonus', font = ('Baskerville Old Face', 12, 'bold underline')).grid(row = 3, column = 2)
        tk.Label(self.results2, bg = '#e1d8b9',
                 text = 'Total', font = ('Baskerville Old Face', 12, 'bold underline')).grid(row = 3, column = 3)

        for k in self.new_char:#Creates loop for output of dictionary results
            tk.Label(self.results2, bg = '#e1d8b9',
                     text = k, font = ('Baskerville Old Face', 10), justify = 'left').grid(sticky = 'w', row = self.count, column = 0)
            tk.Label(self.results2, bg = '#e1d8b9',
                     text = self.new_char[k], font = ('Baskerville Old Face', 10), justify = 'left').grid(row = self.count, column = 1)
            tk.Label(self.results2, bg = '#e1d8b9',
                     text = self.new_race[k], font = ('Baskerville Old Face', 10), justify = 'center').grid(row = self.count, column = 2)
            tk.Label(self.results2, bg = '#e1d8b9',
                     text = total_abil[k], font = ('Baskerville Old Face', 10), justify = 'right').grid(row = self.count, column = 3)
            self.count += 1
        tk.Label(self.results2, bg = '#e1d8b9', text = "***Free Total is any Race Bonuses plus any Level Bonuses***").grid(row = self.count, 
                                                                                                            column = 0, columnspan = 4)
        tk.Label(self.results2, bg = '#e1d8b9', text = "***You can add Free points to any Ability score***").grid(row = self.count + 1, 
                                                                                                   column = 0, columnspan = 4)
        tk.Label(self.results2, bg = '#e1d8b9').grid(row = self.count + 2, column = 0, columnspan = 4)
        self.geometry("%dx%d+%d+%d" % (self.width, new_height, self.x, new_y))
        
    def total(self,x,y,z):#creates total dictionary
        #This functions performs calculation on results already queried and returns new dict
        _base = x #Dict of values previousl determined
        _bonus = y #Dict of values previousl determined
        _free = z #Dict of values previousl determined
        self.tot = {} #Sets storage for new dictionary of calculated values
        #Creates keys and values for new dictionary
        self.tot['Strength'] = (_base.get('Strength') + _bonus.get('Strength'))
        self.tot['Constitution'] = (_base.get('Constitution') + _bonus.get('Constitution'))
        self.tot['Dexterity'] = (_base.get('Dexterity') + _bonus.get('Dexterity'))
        self.tot['Intelligence'] = (_base.get('Intelligence') + _bonus.get('Intelligence'))
        self.tot['Wisdom'] = (_base.get('Wisdom') + _bonus.get('Wisdom'))
        self.tot['Charisma'] = (_base.get('Charisma') + _bonus.get('Charisma'))
        self.tot['Free'] = (_bonus.get('Free') + _free.get('Free'))
        return self.tot        
        
class Horde(tk.Toplevel):
    #This is window for horde maker
    def __init__(self, parent):
        super().__init__(parent)
        #Sets window parameters as in main but for this window
        self.width = 400
        self.height = 350
        self.screen_wid = self.winfo_screenwidth()
        self.screen_hei = self.winfo_screenheight()
        self.x = (self.screen_wid/2) - (self.width/2)
        self.y = (self.screen_hei/2) - (self.height/2)
        self.geometry("%dx%d+%d+%d" % (self.width, self.height, self.x, self.y))
        self.configure(bg = '#e1d8b9')
        self.style = ttk.Style()
        self.style.configure('nbutton.TButton', background = '#e1d8b9', width = 18, height = 34)
        self.title("The Horde")
        self.back_image = tk.PhotoImage(file = os.path.abspath(os.path.join(os.getcwd(), 'Images', 'mon_back3.gif')))
        self.win3_set()#Begins the bas layout of widgets

    def win3_set(self):    
        self.intro1_frame = tk.Frame(self, bg = '#e1d8b9')#Frame for horde maker intro
        self.intro1_frame.pack()
        self.intro1 = tk.Label(self.intro1_frame, bg = '#e1d8b9', image = self.back_image)
        self.intro1.grid(row = 0, column = 0, sticky = 'nsew', columnspan = 2)
        
        tk.Label(self.intro1_frame, text = "Let's Build Your Horde",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '20', 'bold')).grid(row = 1, column = 0, columnspan = 2)
        tk.Label(self.intro1_frame, text = "Enter the Max HP for your Monsters",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '12')).grid(row = 2, column = 0, columnspan = 2)
        
        self.entry1 = tk.StringVar(self.intro1_frame, 10)#Sets container for options menu and sets default
        self.entry2 = tk.StringVar(self.intro1_frame, 5)#Sets container for options menu and sets default

        self.mon_hp = ttk.Entry(self.intro1_frame, width = 2, textvariable = self.entry1)
        self.mon_hp.grid(row = 3, column = 0, columnspan = 2)
        
        def limit1(*args):#Limits number of digits permitted in field
            value = self.entry1.get()
            if len(value) > 2:
                self.entry1.set(value[:2])
        
        self.entry1.trace('w',limit1)#monitors field as input is enteres

        tk.Label(self.intro1_frame, text = "Enter the Number of Monsters in Your Horde",
                  bg = '#e1d8b9', font = ('Baskerville Old Face', '12')).grid(row = 4, column = 0, columnspan = 2)
        self.mon_num = ttk.Entry(self.intro1_frame, width = 2, textvariable = self.entry2)
        self.mon_num.grid(row = 5, column = 0, columnspan = 2)
        
        def limit2(*args):#Limits number of digits permitted in field
            value = self.entry2.get()
            if len(value) > 2:
                self.entry2.set(value[:2])
        
        self.entry2.trace('w',limit2)#monitors field as input is enteres
        
        self.results1 = tk.Frame(self.intro1_frame, bg = '#e1d8b9')#setting up results panel
        self.results1.grid(row= 7, column = 0, columnspan = 2)
        
        ttk.Button(self.intro1_frame, text = "Submit", style = 'nbutton.TButton',
                   command = self.submit1).grid(row = 6, column = 0, sticky = 'e', pady = 5)
        ttk.Button(self.intro1_frame, text = "Exit", style = 'nbutton.TButton',
                   command = self.destroy).grid(row = 6, column = 1, sticky = 'w', pady = 5) 
        
    def submit1(self):#Main character function that collects and performs work on data then returns results
        Horde_Maker.clear_frame(self.results1)
        self.geometry("%dx%d+%d+%d" % (self.width, self.height, self.x, self.y))
        new_height = 535
        new_y = (self.screen_hei/2) - (new_height/2)
        self.count = 0
        self.count2 = 0
        self._seq = 0#Counter variable
        self._submitvar = self.mon_build()
        self._list_length = len(self.mon)
        self._mid = self._list_length//2
        self._list1 = self.mon[:self._mid]
        self._list2 = self.mon[self._mid:]
        for i in range(len(self._list2)):#Begins output of results
                self._seq = self._seq + 1
                self.mon_result = tk.Label(self.results1, justify = LEFT, text = "Monster {} is {} HP.".format(self._seq, self._list2[i]),
                                            bg = '#e1d8b9', fg = 'black', font = ('Baskerville Old Face', '11'))
                self.mon_result.grid(row = self.count, column = 0, sticky = 'w', padx = (5,17))
                self.count +=1
        for i in range(len(self._list1)):#Begins output of results
                self._seq = self._seq + 1
                self.mon_result = tk.Label(self.results1, justify = LEFT, text = "Monster {} is {} HP.".format(self._seq, self._list1[i]),
                                            bg = '#e1d8b9', fg = 'black', font = ('Baskerville Old Face', '11'))
                self.mon_result.grid(row = self.count2, column = 2, sticky = 'w', padx = (17,5))
                self.count2 +=1
        self.geometry("%dx%d+%d+%d" % (self.width, new_height, self.x, new_y))

    def mon_build(self):#this section doeas work on data collected 
        self.mon = []#sets list container 
        self.var1 = self.mon_hp.get()#receives values
        if Checks.is_int(self.var1) == False:#verifies imput can be used 
            messagebox.showerror(title = 'Too Low', message = """You know better than that.  Please try again.""") 
        self.var2 = self.mon_num.get()
        if Checks.is_int(self.var2) == False or int(self.var2) > 15:#verifies imput can be used
            messagebox.showerror(title = 'Amount Error', message = """You should be building a horde, not an army.
Please try again and keep your horde between 1 and 15.""")
        else:
            self.mon = Checks.rangen(self.var1, self.var2)#list is created
            return self.mon

def main():#starts program and begins run            
    app = Horde_Maker()
    app.mainloop()
    
if __name__ == "__main__": main()
