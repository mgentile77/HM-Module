"""
SDEV 140-53P
T. Newell

Final Project

***Race Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""

"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""


import os

#This section creates dictionary table for the race files
race_file = {}
race_file['1'] = 'Dragonborn.txt'
race_file['2'] = 'Dwarf.txt'
race_file['3'] = 'Elf.txt'
race_file['4'] = 'Genasi.txt'
race_file['5'] = 'Half_elf.txt'
race_file['6'] = 'Half_orc.txt'
race_file['7'] = 'Halfling.txt'
race_file['8'] = 'Human.txt'
race_file['9'] = 'Tiefling.txt'


class Race_main:#This mod is used to query request and return results to main
    
    def __init__(self):#this establishes the class and sets up dictionary object
        self.char_def = {}
        self.parentDirectory = os.path.abspath(os.path.join(os.getcwd()))
    def race_main(self,x):#Receives input and generates the desired output
        self.char_def = self.char_file(x)#This section collects and sends race dictionary results
        return self.char_def
            
    def main_char_def(self,x):#Changes character .txt list to definitions and returns dictionary of results
        self.charatt = {}
        for line in x:
            (key, value) = line.split()
            self.charatt[(key)] = int(value)
        return self.charatt

    def char_file(self, race):#This section opens the .txt file for character class selected
        
        self.file = open(os.path.join(self.parentDirectory, 'text_files', race_file.get(race)), "r")
        self.details = self.main_char_def(self.file)
        self.file.close()
        return self.details

