"""
SDEV 140-53P
T. Newell

Final Project

***Class GUI Main***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""
"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""




#Imports needed Modules
import tkinter as tk
from tkinter import *
from tkinter.constants import *
from tkinter import ttk
from tkinter import messagebox
from class_mod import Class_main
from race_mod import Race_main
from level_mod import Level_Bonus
from checks_mod import *


#Creates Class Dictionary for use
class_def = {}
class_def['1'] = 'Artificer'
class_def['2'] = 'Barbarian'
class_def['3'] = 'Bard (Dexterity Preferred)'
class_def['4'] = 'Bard (Wisdom Preferred)'
class_def['5'] = 'Cleric'
class_def['6'] = 'Druid (Charisma Preferred)'
class_def['7'] = 'Druid (Constitution Preferred)'
class_def['8'] = 'Fighter (Dexterity Preferred)'
class_def['9'] = 'Fighter (Strength Preferred)'
class_def['10'] = 'Monk'
class_def['11'] = 'Paladin'
class_def['12'] = 'Ranger'
class_def['13'] = 'Rogue'
class_def['14'] = 'Sorcerer'
class_def['15'] = 'Warlock'
class_def['16'] = 'Wizard'


#Creates Race Dictionary for Use
race_def = {}
race_def['1'] = 'Dragonborn'
race_def['2'] = 'Dwarf'
race_def['3'] = 'Elf'
race_def['4'] = 'Genasi'
race_def['5'] = 'Half-Elf'
race_def['6'] = 'Half-Orc'
race_def['7'] = 'Halfling'
race_def['8'] = 'Human'
race_def['9'] = 'Tiefling'



class Horde_Maker:
    #Main Window class all other windows come from here
    def __init__(self,root):
        #Initializes the main window and starts program
        self.app = root
        #This sections creates window size and location on pop up 
        width = 300
        height = 200
        screen_wid = root.winfo_screenwidth()
        screen_hei = root.winfo_screenheight()
        x = (screen_wid/2) - (width/2)
        y = (screen_hei/2) - (height/2)
        self.app.title("Horde Maker")
        self.app.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.app.protocol("WM_DELETE_WINDOW", self.disable_Xclose)
        #Begins layout of window widgets
        self.set_up()
        
    def set_up(self):
        #sets up window widgets for this class    
        self.frame_header = ttk.Frame()#Frame for image
        self.frame_header.pack()
        
        self.frame_start = ttk.Frame()#Frame for start welcome and instructions
        self.frame_start.pack()
        ttk.Label(self.frame_start, text = "Welcome To The").pack()
        ttk.Label(self.frame_start, text = "HORDE MAKER").pack()
        ttk.Label(self.frame_start, text = "Choose Your Path").pack()
        
        self.frame_buttons = ttk.Frame()#Frame for buttons and pops buttons
        self.frame_buttons.pack()
        but_horde = ttk.Button(self.frame_buttons, text = "Horde Maker", command = self.hordebutton)
        but_horde.grid(row = 0, column = 0)
        
        but_char = ttk.Button(self.frame_buttons, text = "Character Builder", command = self.characterbutton)
        but_char.grid(row = 0, column = 1)
        ttk.Button(self.frame_buttons, text = 'Exit', command = lambda : exit()).grid(row = 1, column = 0, columnspan = 2)

    #Begins Class methods used in functions of of buttons
    def hordebutton(self):#opens Horde window
        self.hord_button = Horde()
        # self.disable_but()
        
    def characterbutton(self):#opens Character Window
        self.char_button = Character()
        # self.disable_but()

    #Creates parent class instructions for other windows    
    def clear_frame(self,frame):#Destroys child window on exit 
        for widgets in frame.winfo_children():
            widgets.destroy() 

    def disable_Xclose(self):#prevents closing the window by using corner X
        pass
    
    # @staticmethod
    # def disable_but():
    #     but_horde.config(state = DISABLED)
    #     but_char.config(state = DISABLED)
    
    # @staticmethod
    # def enable_but():
    #     but_horde.config(state = NORMAL)
    #     but_char.config(state = NORMAL)

       
class Character(Horde_Maker):
    #Begins the character window
    global total_abil #sets variable to be used throughout class
    total_abil = {} #creates dictionary list for later use

    def __init__(self):
        #Sets window parameters as in main but for this window
        self.new_win2 = tk.Toplevel()
        width = 450
        height = 500
        screen_wid = self.new_win2.winfo_screenwidth()
        screen_hei = self.new_win2.winfo_screenheight()
        x = (screen_wid/2) - (width/2)
        y = (screen_hei/2) - (height/2)
        self.new_win2.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.new_win2.title("Character Creator")
        self.new_win2.protocol("WM_DELETE_WINDOW", self.disable_Xclose)
        self.win2_set()#Begins the bas layout of widgets

    def win2_set(self):
        #contains widget layout for this window   
        self.options1 = tk.StringVar(self.new_win2, class_def['1'])#Sets container for options menu and sets default
        self.options2 = tk.StringVar(self.new_win2, race_def['1'])#Sets container for options menu and sets default
        
        self.frame_head3 = ttk.Frame(self.new_win2)#Frame for image
        self.frame_head3.pack()
        
        self.intro2 = ttk.Frame(self.new_win2)#Frame for horde maker intro
        self.intro2.pack()
        
        #Begins options menus and entry menu
        ttk.Label(self.intro2, text = "Time to get you a character!").pack()
        ttk.Label(self.intro2, text = "Choose your Class").pack()
        self.menu1 = ttk.OptionMenu(self.intro2, self.options1, *class_def.values())
        self.menu1.pack()
        ttk.Label(self.intro2, text = "Choose your Race").pack()
        self.menu2 = ttk.OptionMenu(self.intro2, self.options2, *race_def.values())
        self.menu2.pack()
        ttk.Label(self.intro2, text = "Enter your player Level").pack()
        
        self.entry3 = tk.StringVar(self.intro2, 3)#creates container for entry 
        
        self.char_lev = ttk.Entry(self.intro2, width = 2, textvariable = self.entry3)
        self.char_lev.pack()
        
        def limit3(*args):#Limits number of digits permitted in field
            value = self.entry3.get()
            if len(value) > 2:
                self.entry3.set(value[:2])
        
        self.entry3.trace('w', limit3)#monitors field as input is enteres 
        
        self.results2 = ttk.Frame(self.new_win2)#setting up results panel
        self.results2.pack()
        
        self.char_but = ttk.Frame(self.new_win2)#setting up buttons panel
        self.char_but.pack()
        
        ttk.Button(self.char_but, text = "Submit", command = self.submit2).grid(row = 0, column = 0)
        ttk.Button(self.char_but, text = "Exit", command = self.leave2).grid(row = 0, column = 1)
        
    def get_class(self):#creates method for returning value
        for k, v in class_def.items():
            if self.options1.get() == v:
                return k
    
    def get_race(self):#creates method for returning value
        for k,v,in race_def.items():
            if self.options2.get() == v:
                return k
        
    def clear_frame(self,frame):#deletes prevous results before new results are generated
        for widgets in frame.winfo_children():
            widgets.destroy()
            
    def leave2(self):#exits window
        # Horde_Maker.enable_but()
        self.new_win2.destroy()
        
    def submit2(self):#Main character function that collects and performs work on data then returns results
        
        self.count = 4 #Counter variable
        self.clear_frame(self.results2)#Clears results frame
        #begins to fetch data from other mods and produce results
        self.myclass = self.get_class()
        self.myrace = self.get_race()
        self.mylevel = self.entry3.get()
        self.new_char = Class_main().class_main(self.myclass)
        self.new_race = Race_main().race_main(self.myrace)
        self.new_level = Level_Bonus().level_bonus(self.mylevel)
        total_abil = self.total(self.new_char, self.new_race, self.new_level)
        #begins output of results
        ttk.Label(self.results2).grid(row = 0, column = 0, columnspan = 4)
        your_char = "This is your level {} {} {}.".format(self.mylevel, race_def[self.myrace], class_def[self.myclass])
        ttk.Label(self.results2, text = your_char).grid(row = 1, column = 0, columnspan = 4)
        ttk.Label(self.results2).grid(row = 2, column = 0, columnspan = 4)
        ttk.Label(self.results2, text = 'Ability', font = ('arial', 12, 'underline'), justify = 'left').grid(sticky = 'w', row = 3, column = 0)
        ttk.Label(self.results2, text = 'Base', font = ('arial', 12, 'underline'), justify = 'left').grid(row = 3, column = 1)
        ttk.Label(self.results2, text = 'Race Bonus', font = ('arial', 12, 'underline')).grid(row = 3, column = 2)
        ttk.Label(self.results2, text = 'Total', font = ('arial', 12, 'underline')).grid(row = 3, column = 3)

        for k in self.new_char:#Creates loop for output of dictionary results
            ttk.Label(self.results2, text = k, font = ('arial', 10), justify = 'left').grid(sticky = 'w', row = self.count, column = 0)
            ttk.Label(self.results2, text = self.new_char[k], font = ('arial', 10), justify = 'left').grid(row = self.count, column = 1)
            ttk.Label(self.results2, text = self.new_race[k], font = ('arial', 10), justify = 'center').grid(row = self.count, column = 2)
            ttk.Label(self.results2, text = total_abil[k], font = ('arial', 10), justify = 'right').grid(row = self.count, column = 3)
            self.count += 1
        
        ttk.Label(self.results2).grid(row = 0, column = 0, columnspan = 4)
        ttk.Label(self.results2, text = "***Free Total is any Race Bonuses plus any Level Bonuses***").grid(row = self.count, 
                                                                                                            column = 0, columnspan = 4)
        ttk.Label(self.results2, text = "***You can add Free points to any Ability score***").grid(row = self.count + 1, 
                                                                                                   column = 0, columnspan = 4)
        ttk.Label(self.results2).grid(row = self.count + 2, column = 0, columnspan = 4)
        
    def total(self,x,y,z):#creates total dictionary
        #This functions performs calculation on results already queried and returns new dict
        _base = x #Dict of values previousl determined
        _bonus = y #Dict of values previousl determined
        _free = z #Dict of values previousl determined
        self.tot = {} #Sets storage for new dictionary of calculated values
        #Creates keys and values for new dictionary
        self.tot['Strength'] = (_base.get('Strength') + _bonus.get('Strength'))
        self.tot['Constitution'] = (_base.get('Constitution') + _bonus.get('Constitution'))
        self.tot['Dexterity'] = (_base.get('Dexterity') + _bonus.get('Dexterity'))
        self.tot['Intelligence'] = (_base.get('Intelligence') + _bonus.get('Intelligence'))
        self.tot['Wisdom'] = (_base.get('Wisdom') + _bonus.get('Wisdom'))
        self.tot['Charisma'] = (_base.get('Charisma') + _bonus.get('Charisma'))
        self.tot['Free'] = (_bonus.get('Free') + _free.get('Free'))
        return self.tot        
        
class Horde(Horde_Maker):
    #This is window for horde maker
    def __init__(self):
        #Sets window parameters as in main but for this window
        self.new_win1 = tk.Toplevel()
        width = 350
        height = 450
        screen_wid = self.new_win1.winfo_screenwidth()
        screen_hei = self.new_win1.winfo_screenheight()
        x = (screen_wid/2) - (width/2)
        y = (screen_hei/2) - (height/2)
        self.new_win1.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.new_win1.title("The Horde")
        self.new_win1.geometry("350x450")
        self.new_win1.protocol("WM_DELETE_WINDOW", self.disable_Xclose)
        self.win3_set()#Begins the bas layout of widgets

    def win3_set(self):    
        self.intro1 = ttk.Frame(self.new_win1)#Frame for horde maker intro
        self.intro1.pack()
        
        ttk.Label(self.intro1, text = "Let's Build Your Horde").pack()
        ttk.Label(self.intro1, text = "Enter the Max HP for your Monsters").pack()
        
        self.entry1 = tk.StringVar(self.intro1, 10)#Sets container for options menu and sets default
        self.entry2 = tk.StringVar(self.intro1, 5)#Sets container for options menu and sets default

        self.mon_hp = ttk.Entry(self.intro1, width = 2, textvariable = self.entry1)
        self.mon_hp.pack()
        
        
        def limit1(*args):#Limits number of digits permitted in field
            value = self.entry1.get()
            if len(value) > 2:
                self.entry1.set(value[:2])
        
        self.entry1.trace('w',limit1)#monitors field as input is enteres

        ttk.Label(self.intro1, text = "Enter the Number of Monsters in Your Horde").pack()
        self.mon_num = ttk.Entry(self.intro1, width = 2, textvariable = self.entry2)
        self.mon_num.pack()
        
        def limit2(*args):#Limits number of digits permitted in field
            value = self.entry2.get()
            if len(value) > 2:
                self.entry2.set(value[:2])
        
        self.entry2.trace('w',limit2)#monitors field as input is enteres
        
        self.results1 = ttk.Frame(self.new_win1)#setting up results panel
        self.results1.pack()
        
        self.mon_but = ttk.Frame(self.new_win1)#setting up buttons panel
        self.mon_but.pack()
        
        but1 = ttk.Button(self.mon_but, text = "Submit", command = self.submit1).grid(row = 0, column = 0)
        but2 = ttk.Button(self.mon_but, text = "Exit", command = self.leave1).grid(row = 0, column = 1) 
        
    def leave1(self):#exits window
        # Horde_Maker.enable_but()
        self.new_win1.destroy()

        
    def submit1(self):#Main character function that collects and performs work on data then returns results
        self.clear_frame(self.results1)
        self._seq = 0#Counter variable
        self._submitvar = self.mon_build()
        for i in range(len(self.mon)):#Begins output of results
                self._seq = self._seq + 1
                self.mon_result = ttk.Label(self.results1, text = "Monster {} is {} HP.".format(self._seq, self._submitvar[i]))
                self.mon_result.pack()

    def mon_build(self):#this section doeas work on data collected 
        self.mon = []#sets list container 
        self.var1 = self.mon_hp.get()#receives values
        if Checks.is_int(self.var1) == False:#verifies imput can be used 
            messagebox.showerror(title = 'Too Low', message = """You know better than that.  Please try again.""") 
        self.var2 = self.mon_num.get()
        if Checks.is_int(self.var2) == False or int(self.var2) > 15:#verifies imput can be used
            messagebox.showerror(title = 'Amount Error', message = """You should be building a horde, not an army.
Please try again and keep your horde between 1 and 15.""")
        else:
            self.mon = Checks.rangen(self.var1, self.var2)#list is created
            return self.mon

def main():#starts program and begins run            
    
    root = tk.Tk()
    app = Horde_Maker(root)
    root.mainloop()
    
if __name__ == "__main__": main()
