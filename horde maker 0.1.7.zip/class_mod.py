"""
SDEV 140-53P
T. Newell

Final Project

***Class Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""
"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""


from checks_mod import *
import os

#This section creates dictionary for the character class files
class_file = {}
class_file['1'] = 'Artificer.txt'
class_file['2'] = 'Barbarian.txt'
class_file['3'] = 'bard_dex.txt'
class_file['4'] = 'Bard_wis.txt'
class_file['5'] = 'Cleric.txt'
class_file['6'] = 'Druid_cha.txt'
class_file['7'] = 'Druid_con.txt'
class_file['8'] = 'Fighter_dex.txt'
class_file['9'] = 'Fighter_str.txt'
class_file['10'] = 'Monk.txt'
class_file['11'] = 'Paladin.txt'
class_file['12'] = 'Ranger.txt'
class_file['13'] = 'Rogue.txt'
class_file['14'] = 'Sorcerer.txt'
class_file['15'] = 'Warlock.txt'
class_file['16'] = 'Wizard.txt'

class Class_main:#maintains processing for how to handle and manage files
    
    def __init__(self):
        #initiales class by creating dictionary object
        self.char_def = {}
        self.parentDirectory = os.path.abspath(os.path.join(os.getcwd()))
    
    def class_main(self, x):#Receives input and generates the desired output
        char_att = Checks.rangen(18,6,6)#Random number list
        char_att.sort(reverse = True)#Sorted list assignment
        self.char_def = self.char_file(x)#receives input
        for key, value in self.char_def.items():#next section uses txt file to create new dictionary and results
            if value == "max":
                self.char_def[key] = int(max(char_att))
            elif value == "max-1":
                self.char_def[key] = int(char_att[1])
            elif value == "min":
                self.char_def[key] = int(min(char_att))
            else:
                if len(char_att) > 5:
                    x = ran.randint(-4,-2)
                    self.char_def[key] = int(char_att.pop(x))
                elif len(char_att) > 4:
                    x = ran.randint(-3,-2)
                    self.char_def[key] = int(char_att.pop(x))
                else:
                    self.char_def[key] = int(char_att.pop(-2))
        self.char_def['Free'] = '' #Adds the free Key to dict for easy iteration later
        return self.char_def
    
    def char_file(self,char_class_f):#This section opens the .txt file for character class selected
        self.file = open(os.path.join(self.parentDirectory, 'text_files', class_file.get(char_class_f)), "r")
        self.details = self.main_char_def(self.file)
        self.file.close()
        return self.details
    
    def main_char_def(self,x):#Changes character .txt list to definitions and returns definitions
        self.charatt = {}
        for line in x:
            (key, value) = line.split()
            self.charatt[(key)] = value
        return self.charatt


            