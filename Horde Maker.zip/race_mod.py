"""
SDEV 140-53P
T. Newell

Final Project

***Race Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 9-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""

"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""


import random as ran

race_def = {}
race_def['1'] = 'Dragonborn'
race_def['2'] = 'Dwarf'
race_def['3'] = 'Elf'
race_def['4'] = 'Genasi'
race_def['5'] = 'Half-Elf'
race_def['6'] = 'Half-Orc'
race_def['7'] = 'Halfling'
race_def['8'] = 'Human'
race_def['9'] = 'Tiefling'

def is_int(x): 
    #Verifies if entry is interger entered how requested
    try: 
        if int(x) and int(x) > 0:
            return True
        else:
            return False
    except ValueError:
        return False

def main_char_def(x):
    #Changes character .txt list to definitions and returns definitions
    charatt = {}
    for line in x:
        (key, value) = line.split()
        # if value != '0':
        charatt[(key)] = int(value)
        # else:
        #     charatt[(key)] = None
    return charatt
            
#This section opens the .txt file for character class selected
def dragonborn():
    char_file = open("Dragonborn.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details
    
def dwarf():
    char_file = open("Dwarf.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def elf():
    char_file = open("Elf.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def genasi():
    char_file = open("Genasi.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def half_elf():
    char_file = open("Half_Elf.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def half_orc():
    char_file = open("Half_Orc.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def halfling():
    char_file = open("Halfling.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def human():
    char_file = open("Human.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details

def tiefling():
    char_file = open("Tiefling.txt", "r")
    details = main_char_def(char_file)
    char_file.close()
    return details


#This section creates jump table for the charaxter classes
jumpTable1 = {}
jumpTable1['1'] = dragonborn
jumpTable1['2'] = dwarf
jumpTable1['3'] = elf
jumpTable1['4'] = genasi
jumpTable1['5'] = half_elf
jumpTable1['6'] = half_orc
jumpTable1['7'] = halfling
jumpTable1['8'] = human
jumpTable1['9'] = tiefling

def race_main(race_class):
    #Receives input and generates the desired output
#     menu = """1 - Dragonborn                          2 - Dwarf
# 3 - Elf                                 4 - Genasi
# 5 - Half-Elf                            6 - Half-Orc
# 7 - Halfling                            8 - Human
# 9 - Tiefling"""
    # print (menu)
    # race_class = input ("\nSelect the number for your character's race:\n")
    # while is_int(race_class) == False or int(race_class) > 9:
    #     #Verifies input for this jumptable
    #     print ("That was not entered correctly.  Please try again.")
    #     race_class = input ("\nSelect the number for your character' race:\n")
    char_def = jumpTable1[race_class]()
    #checks for accuracy, will be removed before deployment
    return char_def
#     print (char_def)
#     #Finally we print results for the character class
#     print ("\nYour {} has these bonuses (Free points can be added anywhere):".format(race_def[race_class]))
#     for k in char_def:
#         print ("%-18s%-5s" %(k, char_def[k]))

# if __name__ == race_main():
#     race_main()
            