"""
SDEV 140-53P
T. Newell

Final Project

***Horde Main***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 9-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""
#This section imports all my other modules
import level_mod as level
import horde_mod as horde
import class_mod as char
import race_mod as race

#This section sets up class and race dictionaries
class_def = {}
class_def['1'] = 'Artificer'
class_def['2'] = 'Barbarian'
class_def['3'] = 'Bard (Dexterity Preferred)'
class_def['4'] = 'Bard (Wisdom Preferred)'
class_def['5'] = 'Cleric'
class_def['6'] = 'Druid (Charisma Preferred)'
class_def['7'] = 'Druid (Constitution Preferred)'
class_def['8'] = 'Fighter (Dexterity Preferred)'
class_def['9'] = 'Fighter (Strength Preferred)'
class_def['10'] = 'Monk'
class_def['11'] = 'Paladin'
class_def['12'] = 'Ranger'
class_def['13'] = 'Rogue'
class_def['14'] = 'Sorcerer'
class_def['15'] = 'Warlock'
class_def['16'] = 'Wizard'

race_def = {}
race_def['1'] = 'Dragonborn'
race_def['2'] = 'Dwarf'
race_def['3'] = 'Elf'
race_def['4'] = 'Genasi'
race_def['5'] = 'Half-Elf'
race_def['6'] = 'Half-Orc'
race_def['7'] = 'Halfling'
race_def['8'] = 'Human'
race_def['9'] = 'Tiefling'

#This section sets up menu options
race_menu = """\n1 - Dragonborn                          2 - Dwarf
3 - Elf                                 4 - Genasi
5 - Half-Elf                            6 - Half-Orc
7 - Halfling                            8 - Human
9 - Tiefling"""

class_menu = """\n1 - Artificer                           2 - Barbarian
3 - Bard (Dex preferred)                4 - Bard (Wis preferred)
5 - Cleric                              6 - Druid (Cha preferred)
7 - Druid (Con preferred)               8 - Fighter (Dex preferred)
9 - Fighter (Str preferred)             10 - Monk
11 - Paladin                            12 - Ranger
13 - Rogue                              14 - Sorcerer
15 - Warlock                            16 - Wizard"""

#This section is for my verification functions
def is_int(x): 
    #Verifies if entry is interger entered how requested
    try: 
        if int(x) and int(x) > 0:
            return True
        else:
            return False
    except ValueError:
        return False
    
def again(y):
    #Verifies if entry is valid
    if y == "Y" or y == "N":
        return True
    else:
        print("I did not understand your response.  Please try again")
        return False

#This is my main program
def main():
    #This section sets up local variables
    QUIT = ""
    seq = 0
    rollagain = ""
    new_char = ""
    menu = "1 - Create your Horde            2 - Create a character\n"
    print (menu)
    choice = input ("Select your option (or nothing to quit):\n")
    while choice != QUIT:
        #Begins input and processing of desired information
        while is_int(choice) == False or int(choice) > 2:
            #Verifies input for choice
            print ("That was not entered correctly.  Please try again.")
            choice = input ("\nSelect your option (or nothing to quit):\n")
        if choice == '1':
            #This section is for building a monster horde
            while rollagain != "N":
                mon = horde.horde()
                for i in range(len(mon)):
                #Begins output of results
                    seq = seq + 1
                    print ("Monster {} is {} HP".format(seq,mon[i]))
                seq = 0
                rollagain = input ("\nRoll Again? (Y/N)\n").upper()
                while again(rollagain) == False:
                    rollagain = input ("\nRoll Again? (Y/N)\n").upper()
        else:
            #This section builds characters
            while new_char != "N":
                print (class_menu)
                char_clas = input ("\nSelect the number for your character's class:\n")
                while is_int(char_clas) == False or int(char_clas) > 16:
                    #Verifies input for this jumptable
                    print ("That was not entered correctly.  Please try again.")
                    char_clas = input ("\nSelect the number for your character's class:\n")
                print (race_menu)
                race_clas = input ("\nSelect the number for your character's race:\n")
                while is_int(race_clas) == False or int(race_clas) > 9:
                    #Verifies input for this jumptable
                    print ("That was not entered correctly.  Please try again.")
                    race_clas = input ("\nSelect the number for your character' race:\n")
                #This section sets storage for processing from other modules 
                tot = {}
                base = char.att_main(char_clas)
                bonus = race.race_main(race_clas)
                free = level.abil_bonus()
                #Begins output of results
                print ("\nYou {} {} has these stats:\n".format(race_def[race_clas], class_def[char_clas]))
                print ("\u0332".join("%-18s%-12s%-12s%12s" % ('Ability', 'Base', 'Race Bonus', 'Total')))
                #Creating new temp dictionary for calculations and output
                tot['Strength'] = (base.get('Strength') + bonus.get('Strength'))
                tot['Constitution'] = (base.get('Constitution') + bonus.get('Constitution'))
                tot['Dexterity'] = (base.get('Dexterity') + bonus.get('Dexterity'))
                tot['Intelligence'] = (base.get('Intelligence') + bonus.get('Intelligence'))
                tot['Wisdom'] = (base.get('Wisdom') + bonus.get('Wisdom'))
                tot['Charisma'] = (base.get('Charisma') + bonus.get('Charisma'))
                tot['Free'] = (bonus.get('Free') + free.get('Free'))
                for k in bonus:
                #Prints results
                    print ("%-18s%-16s%-12s%8s\n" %(k, base[k], bonus[k], tot[k]))
                print ("***Free Total is any Race Bonuses plus any Level Bonuses***")
                print ("***You can add Free points to any Ability score***")
                new_char = input ("\nWould you like to build a new character? (Y/N)\n").upper()
                while again(new_char) == False:
                    new_char = input ("\nWould you like to build a new character?  (Y/N)\n").upper()
        print (menu)
        choice = input ("Select your option (or nothing to quit):\n")

    print ("Thank you for using the HORDE MAKER")
 
if __name__ == main():
    main()