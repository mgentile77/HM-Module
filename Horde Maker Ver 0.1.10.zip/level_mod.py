"""
SDEV 140-53P
T. Newell

Final Project

***Level Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""

"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""


from checks_mod import *
from tkinter import messagebox

#This section sets dictionionary for level points
levelbonus = {}
levelbonus[4] = 2
levelbonus[8] = 4
levelbonus[12] = 6
levelbonus[16] = 8
levelbonus[19] = 10

class Level_Bonus:#Main bonus calculator
    def __init__(self):#This section sets the local variables and colledcts input
        self.ability = {}
        
    def level_bonus(self,x):#Verififies input and processes data for collection as dictionary object
        if Checks.is_int(x) == False or int(x) > 20:
            messagebox.showerror(title = "Too Low or Too High", message = """What are you thinking?
You know that number doesn't make sense.
Please try again.""")
        else:
            #This section sets the level bonus and prepares a dictionary
            if int(x) >18:
                self.ability['Free'] = levelbonus.get(19)
            elif int(x) > 15:
                self.ability['Free'] = levelbonus.get(16)
            elif int(x) > 11:
                self.ability['Free'] = levelbonus.get(12)
            elif int(x) > 7:
                self.ability['Free'] = levelbonus.get(8)
            elif int(x) > 3:
                self.ability['Free'] = levelbonus.get(4)
            else:
                self.ability['Free'] = 0
            return self.ability #Returns results
