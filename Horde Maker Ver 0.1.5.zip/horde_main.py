"""
SDEV 140-53P
T. Newell

Final Project

***Horde Main***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""
#This section imports all my other modules
import level_mod as level
import horde_mod as horde
import class_mod as char
import race_mod as race
import total_cal as total

#This section is for my verification functions
def is_int(x): 
    #Verifies if entry is interger entered how requested
    try: 
        if int(x) and int(x) > 0:
            return True
        else:
            return False
    except ValueError:
        return False
    
def again(y):
    #Verifies if entry is valid
    if y == "Y" or y == "N":
        return True
    else:
        print("I did not understand your response.  Please try again")
        return False
    
def rollagain():
    #This either keeps you in a subprogram or returns you to main by providing basic selection 
    
    _rollagain = input ("\nRoll Again? (Y/N)\n").upper()
    if again(_rollagain) == False:
        rollagain()
    if _rollagain == "N":
        return False
    else:
        return True
    
def choice():
    #This creates and provides input options for the main 
    
    #this section creates local variables and provides selction output of desired response
    menu = "\n1 - Create your Horde            2 - Create a character\n"
    print (menu)
    _choice = input ("Select your option (or nothing to quit):\n")
    if _choice != "" and choices(_choice) == False:
        return choice()
    else:
        return _choice

def choices(x):
    #This verifies the initial input options
    
    if is_int(x) == False or int(x) > 2:
        #Verifies input for choice
        print ("That was not entered correctly.  Please try again.\n")
        return False
    else:
        return True

    
def mon_build():
    #This section is the Monster Horde builder portion of the main program
    
    #this section brings in results from other mods and sets up local variables
    seq = 0
    mon = horde.horde()
    for i in range(len(mon)):
    #Begins output of results
        seq = seq + 1
        print ("Monster {} is {} HP".format(seq,mon[i]))
    seq = 0
    if rollagain() == False:
        main ()
    else:
        mon_build()

def char_build():
    #This is the Character builder portion of the main program
    
    #this section brings in the files from other mods and sets up any local variables        
    tot = {}
    charClass = char.att_main()
    base, char_clas = charClass[0], charClass[1]
    raceClass = race.race_main()
    bonus, race_clas = raceClass[0], raceClass[1]
    free = level.abil_bonus()
    tot = total.total(base,bonus,free)
    #Begins output of results
    print ("\nYou {} {} has these stats:\n".format(race_clas, char_clas))
    print ("\u0332".join("%-15s%-10s%-10s%12s" % ('Ability', 'Base', 'Race Bonus', 'Total')))
    for k in bonus:
    #Prints results
        print ("%-16s%-13s%-8s%8s\n" %(k, base[k], bonus[k], tot[k]))
    print ("***Free Total is any Race Bonuses plus any Level Bonuses***")
    print ("***You can add Free points to any Ability score***")
    
    if rollagain() == False:
        main()
    else:
        char_build()


        



#This is my main program
def main():
    #This section sets up local variables
    branch = choice()
    if branch == '1':
        mon_build()
    elif branch == '2':
        #This section builds characters
        char_build()
    else:
        print ("Thank you for using the HORDE MAKER")
 
if __name__ == main():
    main()