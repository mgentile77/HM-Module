"""
SDEV 140-53P
T. Newell

Final Project

***Race Module***

This will create a horde of monsters of varying HP. The user will supply the number of monsters desired in the horde
and the max HP for the monster type.  The program will then produce random HP for each monster in the horde up to the 
max HP for the monster type.

Additionally, this program will assist in quickly producing new characters.  The user will supply the character class,
race and desired level.  The program will then generate a character with random numbers betweem 6-18 per each attribute.
It will then place the numbers in the attribute category that is typically the best fit for the character  class.  It 
will then present and add race boosts to each attribute.  It will also present free points as per the desired level that
that the creator can then add to the desired attributes on their player sheets.
"""

"""Some code is commented out due to being used only for testing when building module.
That code will be cleaned up and removed later."""


import random as ran

#This section creates dictionary table for the race labels
race_def = {}
race_def['1'] = 'Dragonborn'
race_def['2'] = 'Dwarf'
race_def['3'] = 'Elf'
race_def['4'] = 'Genasi'
race_def['5'] = 'Half-Elf'
race_def['6'] = 'Half-Orc'
race_def['7'] = 'Halfling'
race_def['8'] = 'Human'
race_def['9'] = 'Tiefling'

#This section creates dictionary table for the race files
race_file = {}
race_file['1'] = 'Dragonborn.txt'
race_file['2'] = 'Dwarf.txt'
race_file['3'] = 'Elf.txt'
race_file['4'] = 'Genasi.txt'
race_file['5'] = 'Half_elf.txt'
race_file['6'] = 'Half_orc.txt'
race_file['7'] = 'Halfling.txt'
race_file['8'] = 'Human.txt'
race_file['9'] = 'Tiefling.txt'


def is_int(x): 
    #Verifies if entry is interger entered how requested
    try: 
        if int(x) and int(x) > 0:
            return True
        else:
            return False
    except ValueError:
        return False

def main_char_def(x):
    #Changes character .txt list to definitions and returns dictionary of results
    charatt = {}
    for line in x:
        (key, value) = line.split()
        # if value != '0':
        charatt[(key)] = int(value)
        # else:
        #     charatt[(key)] = None
    return charatt
            
#This section opens the .txt file for character race selected
def char_file(race):
    
    file = open(race_file.get(race), "r")
    details = main_char_def(file)
    file.close()
    return details


def race_main():
    #This section is main race bonus generator
    #Receives input and generates the desired output
    menu = """\n1 - Dragonborn                          2 - Dwarf
3 - Elf                                 4 - Genasi
5 - Half-Elf                            6 - Half-Orc
7 - Halfling                            8 - Human
9 - Tiefling"""
    print (menu)
    race_class = input ("\nSelect the number for your character's race:\n")
    while is_int(race_class) == False or int(race_class) > 9:
        #Verifies input for this jumptable
        print ("That was not entered correctly.  Please try again.")
        race_class = input ("\nSelect the number for your character' race:\n")
    #This section collects and sends race dictionary results
    char_def = char_file(race_class)
    return char_def, race_def[race_class]
            